class NetwixValidationError(Exception):
    pass